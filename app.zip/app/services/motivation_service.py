from app.extensions import db
from app.models.motivation import Motivation
from app.models.request_log import RequestLog
from app.services.llm_service import generate_from_llm
from app.utils.parser import parse_llm_response

def create_motivations(theme: str, total: int):
    """Fungsi untuk membuat motivasi baru menggunakan AI dan menyimpannya ke DB."""
    try:
        prompt = f"""
        Dalam format JSON, buat {total} kata-kata motivasi dengan tema "{theme}".
        Format harus persis seperti ini:
        {{
            "motivations": [
                {{"text": "isi motivasi 1"}},
                {{"text": "isi motivasi 2"}}
            ]
        }}
        """

        # Ambil teks mentah dari Gemini
        raw_response = generate_from_llm(prompt)

        # Ubah teks string menjadi list Python menggunakan parser
        motivations = parse_llm_response(raw_response)

        # Simpan log permintaan ke database
        req_log = RequestLog(theme=theme)
        db.session.add(req_log)
        db.session.flush() # Mendapatkan ID untuk relasi foreign key

        saved_texts = []
        for item in motivations:
            text = item.get("text")
            new_m = Motivation(text=text, request_id=req_log.id)
            db.session.add(new_m)
            saved_texts.append(text)

        db.session.commit()
        return saved_texts

    except Exception as e:
        db.session.rollback()
        print(f"Error di create_motivations: {e}")
        raise e

def get_all_motivations(page: int = 1, per_page: int = 10):
    """Fungsi untuk mengambil daftar motivasi yang sudah ada di DB."""
    try:
        query = Motivation.query
        total = query.count()
        data = (
            query
            .order_by(Motivation.id.desc())
            .offset((page - 1) * per_page)
            .limit(per_page)
            .all()
        )

        result = [
            {
                "id": m.id,
                "text": m.text,
                "created_at": m.created_at.isoformat() if m.created_at else None
            } for m in data
        ]

        return {
            "total": total,
            "page": page,
            "per_page": per_page,
            "data": result
        }
    except Exception as e:
        print(f"Error di get_all_motivations: {e}")
        raise e