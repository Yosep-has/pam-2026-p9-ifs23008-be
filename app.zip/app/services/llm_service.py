import google.generativeai as genai
from app.config import Config

def generate_from_llm(prompt: str):
    """Fungsi untuk menghubungi Google Gemini API secara langsung."""
    try:
        genai.configure(api_key=Config.LLM_TOKEN)
        model = genai.GenerativeModel(Config.MODEL_NAME)
        response = model.generate_content(prompt)

        if response and response.text:
            return response.text
        else:
            raise Exception("Respon dari LLM kosong.")
    except Exception as e:
        print(f"Error pada LLM Service: {str(e)}")
        raise e