from flask import Flask
from flask_cors import CORS
from app.config import Config
from app.extensions import db

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    CORS(app)

    # Inisialisasi DB dengan App
    db.init_app(app)

    # Import dan register blueprint di dalam fungsi untuk menghindari circular import
    from app.routes.motivation_routes import bp as motivation_bp
    app.register_blueprint(motivation_bp)

    # Buat database jika belum ada (opsional)
    with app.app_context():
        db.create_all()

    return app